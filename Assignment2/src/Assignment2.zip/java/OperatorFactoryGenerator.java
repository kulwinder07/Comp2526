public class OperatorFactoryGenerator {
    public static OperatorFactory createOperatorFactory(OperatorFactoryType basic) throws UnknownOperatorFactoryException {
        if(basic == null){
            throw new IllegalArgumentException("type cannot be null");
        }
        if(basic == OperatorFactoryType.BASIC)
        {
            return new BasicOperatorFactory();
        }
        else if(basic == OperatorFactoryType.ADVANCED)
        {
            return new AdvancedOperatorFactory();
        }
        else {
            throw new UnknownOperatorFactoryException(basic);
        }
    }
}
