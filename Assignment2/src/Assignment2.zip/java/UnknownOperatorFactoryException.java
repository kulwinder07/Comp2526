public class UnknownOperatorFactoryException extends Exception {
    private OperatorFactoryType operatorFactoryType;

    public UnknownOperatorFactoryException(OperatorFactoryType operatorFactoryType)
    {
        super("Unknown OperatorFactoryType: \"" + operatorFactoryType + "\"");
        this.operatorFactoryType = operatorFactoryType;
    }

    public <E extends Enum<E>> Enum<E> getType()
    {
        return (Enum<E>) operatorFactoryType;
    }
}
