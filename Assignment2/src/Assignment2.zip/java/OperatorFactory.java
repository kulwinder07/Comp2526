public abstract class OperatorFactory {
    public abstract Operator getOperator(String symbol);

    public abstract boolean supports(String symbol);
}
