public class Main
{
    public static void main(final String[] args)
    {
        try
        {
            final Calculator calculatorA;
            final Calculator calculatorB;
            final Calculator calculatorC;
            final OperatorFactory operatorFactoryB;
            final OperatorFactory operatorFactoryC;

            calculatorA = new Calculator();
            operatorFactoryB = OperatorFactoryGenerator.createOperatorFactory(OperatorFactoryType.BASIC);
            calculatorB = new Calculator(operatorFactoryB);
            operatorFactoryC = OperatorFactoryGenerator.createOperatorFactory(OperatorFactoryType.ADVANCED);
            calculatorC = new Calculator(operatorFactoryC);

            calc(calculatorA, 2, "+", 2);   // 4
            calc(calculatorB, 3, "-", 3);   // 0
            calc(calculatorC, 4, "^", 4);   // 256
            calc(calculatorA, 4, "*", 4);   // 16
            calc(calculatorB, 3, "*", 3);   // 9
            calc(calculatorC, 3, "^", 6);   // 729
            calc(calculatorA, 4, "^", 4);   // Unsupported operator: ^
            calc(calculatorB, 4, "^", 4);   // Unsupported operator: ^
        }
        catch(final UnknownOperatorFactoryException ex)
        {
            System.err.println("DO not know how to create a: " + ex.getType().name());
        }
    }

    private static void calc(final Calculator calculator,
                             final int        operandA,
                             final String     symbol,
                             final int        operandB)
    {
        final boolean supportedOperator;

        supportedOperator = calculator.supportsOperator(symbol);

        if(supportedOperator)
        {
            final int answer;

            answer = calculator.calculate(operandA, symbol, operandB);
            System.out.println(answer);
        }
        else
        {
            System.err.println("Unsupported operator: " + symbol);
        }
    }
}
