public class DivisionOperator extends Operator {
    int number1;
    int number2;
    DivisionOperator()
    {

    }

    public int perform(int i, int i1) {
        return i/i1;
    }
}
