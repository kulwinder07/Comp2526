public class ExponentOperator extends Operator {
    @Override
    public int perform(int i, int i1)
    {
        return (int)(Math.pow(i,i1));
    }
}
