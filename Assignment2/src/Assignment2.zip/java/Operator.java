public class Operator {
    public int perform(int i, int i1)
    {
        return i*i1;
    }
}
