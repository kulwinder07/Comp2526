public enum OperatorFactoryType
{
    BASIC,
    ADVANCED,
    JUST_FOR_UNKNOWN_TEST,
}
