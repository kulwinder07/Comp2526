public class AdditionOperator extends Operator {
    int number;
    int number2;
    public AdditionOperator(int number, int number2){

    }

    public AdditionOperator() {

        super();
    }

    public int perform(int i, int i1) {

        return i+i1;
    }
}
