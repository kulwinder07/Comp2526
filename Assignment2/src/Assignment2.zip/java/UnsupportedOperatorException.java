public class UnsupportedOperatorException extends RuntimeException {
    public String symbol;

    UnsupportedOperatorException(String symbol)
    {
        super("Unsupported operator: " + "\"" + symbol + "\"");
        this.symbol = symbol;
    }

    public String getSymbol()
    {
        return symbol;
    }
}
