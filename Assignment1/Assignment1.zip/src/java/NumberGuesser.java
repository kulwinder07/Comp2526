public interface NumberGuesser  {
   int guess(int min, int max);
}
